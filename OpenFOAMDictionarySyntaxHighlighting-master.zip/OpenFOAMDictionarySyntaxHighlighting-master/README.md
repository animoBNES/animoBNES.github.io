OpenFOAM dictionary syntax highlighing for Sublime Text
=======

About
=====

This is a work in progress. Contributions are welcome.

The goal is to build a simple syntax highlighting definition for OpenFOAM
dictionary files to make navigation and editing a little easier.

Editing is done to the YAML file and translated using
[SerializedDataConverter](https://github.com/facelessuser/SerializedDataConverter)